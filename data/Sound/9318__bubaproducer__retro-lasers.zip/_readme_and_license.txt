Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by bubaproducer ( http://www.freesound.org/people/bubaproducer/  )
You can find this pack online at: http://www.freesound.org/people/bubaproducer/packs/9318/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 151026__bubaproducer__laser-shot-water.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151026/
    * license: Attribution
  * 151025__bubaproducer__laser-shot-small-1.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151025/
    * license: Attribution
  * 151024__bubaproducer__laser-shot-small-2.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151024/
    * license: Attribution
  * 151023__bubaproducer__laser-shot-short.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151023/
    * license: Attribution
  * 151022__bubaproducer__laser-shot-silenced.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151022/
    * license: Attribution
  * 151021__bubaproducer__laser-shot-big-3.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151021/
    * license: Attribution
  * 151020__bubaproducer__laser-shot-big-4.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151020/
    * license: Attribution
  * 151019__bubaproducer__laser-shot-element-1.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151019/
    * license: Attribution
  * 151018__bubaproducer__laser-shot-long.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151018/
    * license: Attribution
  * 151017__bubaproducer__laser-element-only-2.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151017/
    * license: Attribution
  * 151016__bubaproducer__laser-shot-big-1.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151016/
    * license: Attribution
  * 151015__bubaproducer__laser-shot-big-2.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151015/
    * license: Attribution
  * 151014__bubaproducer__laser-classic-shot-1.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151014/
    * license: Attribution
  * 151013__bubaproducer__laser-classic-shot-2.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151013/
    * license: Attribution
  * 151012__bubaproducer__laser-classic-shot-3.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151012/
    * license: Attribution
  * 151011__bubaproducer__laser-classic-shot-4.wav
    * url: http://www.freesound.org/people/bubaproducer/sounds/151011/
    * license: Attribution

